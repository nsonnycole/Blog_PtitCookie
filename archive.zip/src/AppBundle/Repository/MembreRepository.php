<?php
namespace AppBundle\Repository;

class UserRepository extends \Doctrine\ORM\EntityRepository implements UserLoaderInterface
{
  
}
